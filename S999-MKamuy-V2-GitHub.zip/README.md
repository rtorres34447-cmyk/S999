# S999 MKamuy Launcher V2.0

Android launcher for S999. Package/application ID: `com.mkamuy.s999` (unchanged from V1.1). Android `versionCode=3`, `versionName=2.0`.

## Features
- Original user-supplied MKamuy logo rendered white with transparent background, on black.
- Minimal tech-style home with large clock/date and understated `AI` shortcut for ChatGPT.
- 50%-open rectangle frames and clean sans-serif text.
- Swipe LEFT for a scrollable two-column grid of installed apps; RIGHT to return HOME.
- AI shortcut opens the installed ChatGPT app or falls back to chatgpt.com in browser.

## Existing S999 GitHub repository (ZIP workflow)
1. Upload **S999-MKamuy-V2-GitHub.zip** to repository root as a single ZIP. Do not extract.
2. Upload/replace **.github/workflows/main.yml** using the separate `main-v2.yml` supplied alongside this ZIP (rename it to `main.yml` when uploading). If the repo has another build workflow that triggers on every push, disable or remove it to avoid duplicate builds.
3. GitHub: Actions > Build S999 MKamuy V2 APK > Run workflow.
4. After success: Artifacts > S999-MKamuy-V2-APK > download > extract > install app-debug.apk.

The workflow uses the exact V2 ZIP filename, not the first ZIP in the repository. The ZIP includes a copy of main.yml for reference, but uploading the ZIP does not install the workflow at the repository root.

Debug builds on a different machine may have a different signing certificate. If Android rejects the update, switch to the system launcher, uninstall the older MKamuy launcher, install V2, then select MKamuy as the HOME app.

Build has not been compiled or hardware-tested in this environment. V2 is a renamed/versioned packaging of the V1.1 layout, not a new visual redesign.
