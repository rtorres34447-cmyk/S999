package com.mkamuy.s999;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.text.TextUtils;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int BG=Color.rgb(8,9,11), WHITE=Color.rgb(233,235,237), MUTED=Color.rgb(137,142,147);
    private LinearLayout screen, body;
    private TextView clock, date;
    private int page=0;
    private float touchX,touchY;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable clockUpdater=new Runnable(){ @Override public void run(){
        if(clock!=null)clock.setText(new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date()));
        if(date!=null)date.setText(new SimpleDateFormat("EEE  dd MMM",Locale.ENGLISH).format(new Date()).toUpperCase(Locale.ENGLISH));
        handler.postDelayed(this,30000);
    }};

    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private TextView label(String s,int size,int color){
        TextView v=new TextView(this);
        v.setText(s);v.setTextSize(size);v.setTextColor(color);v.setIncludeFontPadding(false);
        v.setTypeface(Typeface.create("sans-serif-light",Typeface.NORMAL));v.setGravity(Gravity.CENTER_VERTICAL);
        return v;
    }
    private LinearLayout vertical(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.VERTICAL);return v;}
    private void space(LinearLayout target,int height){target.addView(new View(this),new LinearLayout.LayoutParams(1,dp(height)));}
    private void rule(FrameLayout target,int width,int height,int gravity){
        View v=new View(this);v.setBackgroundColor(MUTED);
        target.addView(v,new FrameLayout.LayoutParams(dp(width),dp(height),gravity));
    }
    // Roughly 50% of the four sides are drawn, leaving two opposite corners open.
    private FrameLayout partialFrame(int w,int h){
        FrameLayout f=new FrameLayout(this);
        f.setLayoutParams(new LinearLayout.LayoutParams(dp(w),dp(h)));
        rule(f,w/2,1,Gravity.TOP|Gravity.LEFT);
        rule(f,1,h/2,Gravity.TOP|Gravity.LEFT);
        rule(f,w/2,1,Gravity.BOTTOM|Gravity.RIGHT);
        rule(f,1,h/2,Gravity.BOTTOM|Gravity.RIGHT);
        return f;
    }
    @Override public void onCreate(Bundle state){super.onCreate(state);render(0);handler.post(clockUpdater);}
    @Override protected void onDestroy(){handler.removeCallbacks(clockUpdater);super.onDestroy();}
    private void render(int next){
        page=next;clock=null;date=null;
        screen=vertical();screen.setBackgroundColor(BG);screen.setPadding(dp(15),dp(11),dp(15),dp(5));
        setContentView(screen);
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);screen.addView(header,new LinearLayout.LayoutParams(-1,dp(28)));
        TextView brand=label("M K A M U Y",11,WHITE);brand.setLetterSpacing(.12f);
        header.addView(brand,new LinearLayout.LayoutParams(0,-1,1));
        TextView pageText=label(page==0?"01 / HOME":"02 / APPS",9,MUTED);pageText.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);header.addView(pageText);
        body=vertical();screen.addView(body,new LinearLayout.LayoutParams(-1,0,1));
        if(page==0)home();else apps();
        TextView footer=label(page==0?"‹     SWIPE LEFT / APPS     ›":"‹     SWIPE RIGHT / HOME     ›",9,MUTED);
        footer.setGravity(Gravity.CENTER);footer.setLetterSpacing(.08f);screen.addView(footer,new LinearLayout.LayoutParams(-1,dp(24)));
        updateClock();
    }
    private void updateClock(){
        if(clock!=null)clock.setText(new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date()));
        if(date!=null)date.setText(new SimpleDateFormat("EEE  dd MMM",Locale.ENGLISH).format(new Date()).toUpperCase(Locale.ENGLISH));
    }
    private void home(){
        space(body,10);
        // User-supplied Japanese MKamuy logo as an understated monochrome mark.
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.mkamuy_logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams logoParams=new LinearLayout.LayoutParams(dp(126),dp(56));logoParams.gravity=Gravity.CENTER_HORIZONTAL;
        body.addView(logo,logoParams);
        space(body,15);
        clock=label("",46,WHITE);clock.setGravity(Gravity.CENTER);clock.setTypeface(Typeface.create("sans-serif-thin",Typeface.NORMAL));
        body.addView(clock,new LinearLayout.LayoutParams(-1,dp(61)));
        date=label("",11,MUTED);date.setGravity(Gravity.CENTER);date.setLetterSpacing(.17f);
        body.addView(date,new LinearLayout.LayoutParams(-1,dp(26)));
        space(body,14);
        TextView ready=label("/  SYSTEM READY",10,MUTED);ready.setLetterSpacing(.15f);ready.setGravity(Gravity.CENTER);
        body.addView(ready,new LinearLayout.LayoutParams(-1,dp(20)));
        space(body,13);
        FrameLayout ai=partialFrame(92,44);
        LinearLayout.LayoutParams aiParams=(LinearLayout.LayoutParams)ai.getLayoutParams();aiParams.gravity=Gravity.CENTER_HORIZONTAL;
        body.addView(ai,aiParams);
        TextView aiLabel=label("AI",15,WHITE);aiLabel.setGravity(Gravity.CENTER);aiLabel.setLetterSpacing(.20f);
        ai.addView(aiLabel,new FrameLayout.LayoutParams(-1,-1));
        ai.setContentDescription("Open AI");ai.setOnClickListener(v->openAI());
    }
    private void openAI(){
        PackageManager pm=getPackageManager();
        Intent app=pm.getLaunchIntentForPackage("com.openai.chatgpt");
        if(app!=null){try{startActivity(app);return;}catch(Exception ignored){}}
        try{startActivity(new Intent(Intent.ACTION_VIEW,android.net.Uri.parse("https://chatgpt.com")));}
        catch(Exception e){Toast.makeText(this,"AI unavailable",Toast.LENGTH_SHORT).show();}
    }
    private void apps(){
        space(body,9);
        TextView title=label("APPLICATIONS",15,WHITE);title.setLetterSpacing(.15f);
        body.addView(title,new LinearLayout.LayoutParams(-1,dp(30)));
        ScrollView scroll=new ScrollView(this);scroll.setVerticalScrollBarEnabled(false);
        body.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout list=vertical();scroll.addView(list);
        PackageManager pm=getPackageManager();
        Intent intent=new Intent(Intent.ACTION_MAIN);intent.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> found=new ArrayList<>(pm.queryIntentActivities(intent,0));
        Collections.sort(found,(a,b)->String.CASE_INSENSITIVE_ORDER.compare(a.loadLabel(pm).toString(),b.loadLabel(pm).toString()));
        LinearLayout row=null;int count=0;
        for(ResolveInfo info:found){
            if(info.activityInfo==null || getPackageName().equals(info.activityInfo.packageName))continue;
            if(count%2==0){row=new LinearLayout(this);list.addView(row,new LinearLayout.LayoutParams(-1,dp(117)));}
            final String pkg=info.activityInfo.packageName,cls=info.activityInfo.name;
            LinearLayout item=vertical();item.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams cell=new LinearLayout.LayoutParams(0,-1,1);
            cell.setMargins(dp(3),dp(2),dp(3),dp(2));row.addView(item,cell);
            FrameLayout open=partialFrame(82,79);item.addView(open);
            ImageView image=new ImageView(this);try{image.setImageDrawable(info.loadIcon(pm));}catch(Exception ignored){}
            open.addView(image,new FrameLayout.LayoutParams(dp(44),dp(44),Gravity.CENTER));
            TextView name=label(info.loadLabel(pm).toString(),11,WHITE);
            name.setGravity(Gravity.CENTER);name.setSingleLine(true);name.setEllipsize(TextUtils.TruncateAt.END);
            item.addView(name,new LinearLayout.LayoutParams(-1,dp(28)));
            item.setContentDescription("Open "+info.loadLabel(pm));
            item.setOnClickListener(v->{try{
                Intent launch=new Intent(Intent.ACTION_MAIN);launch.addCategory(Intent.CATEGORY_LAUNCHER);
                launch.setClassName(pkg,cls);launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(launch);
            }catch(Exception e){Toast.makeText(this,"Could not open app",Toast.LENGTH_SHORT).show();}});
            count++;
        }
        if(count==0){TextView empty=label("NO APPLICATIONS FOUND",12,MUTED);list.addView(empty);}
    }
    @Override public boolean dispatchTouchEvent(MotionEvent event){
        if(event.getActionMasked()==MotionEvent.ACTION_DOWN){touchX=event.getX();touchY=event.getY();}
        if(event.getActionMasked()==MotionEvent.ACTION_UP){
            float dx=event.getX()-touchX,dy=event.getY()-touchY;
            if(Math.abs(dx)>dp(55) && Math.abs(dx)>Math.abs(dy)*1.4f){
                if(dx<0 && page==0){render(1);return true;}
                if(dx>0 && page==1){render(0);return true;}
            }
        }
        return super.dispatchTouchEvent(event);
    }
    @Override public void onBackPressed(){if(page==1)render(0);else super.onBackPressed();}
}
