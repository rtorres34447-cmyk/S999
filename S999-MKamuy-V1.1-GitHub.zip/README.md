# S999 MKamuy Launcher V1.1

Minimalist monochrome Android HOME launcher for the S999.

- Uses the supplied MKamuy logo (monochrome with transparent background).
- Clock, date and understated **AI** shortcut on home (opens installed ChatGPT, fallback browser).
- Swipe left for the separate app drawer with large two-column icons. Swipe right to return.
- Uses simple tech-style sans-serif and roughly 50%-open incomplete rectangles.
- App list is dynamic (all visible launcher apps), scrollable, and opens installed packages.

## GitHub build steps

1. Upload the **contents** of this project ZIP to the root of your existing `S999` repository; preserve folders such as `app/` and `.github/workflows/`.
2. In `.github/workflows/`, **remove the previous `main.yml` build workflow** to avoid duplicate/incompatible builds; use the provided `build-apk.yml` instead.
3. In the repository, open **Actions > Build S999 MKamuy APK > Run workflow**, or push a change to `main`.
4. Open the successful workflow run, download the artifact **S999-MKamuy-V1.1-APK**, unzip the artifact, and install `app-debug.apk` on the S999.

**Important:** The package ID is `com.mkamuy.s999` to match the earlier project source. GitHub debug APKs may be signed with a different debug key from the currently installed app; if Android reports a signature conflict, remove the previous launcher APK before installing V1.1. First select another HOME launcher under Android settings if needed. Re-select MKamuy as HOME after installing. A release keystore is required for seamless signed upgrades.

This is a source project and GitHub Actions build workflow, not a locally compiled APK. Build has not been tested on the S999 hardware.
