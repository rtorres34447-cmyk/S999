# MKamuy S999 — Version 1

A lightweight, black-and-white, Japanese-tech-inspired Android **home launcher** for the S999 watch-phone. No network permissions, advertising, or analytics.

## What's included
- Monochrome status and clock interface
- App drawer listing installed launchable apps
- Tap an app to launch it
- HOME intent registration so you can optionally choose it as your default home screen
- GitHub Actions build that publishes a **debug APK** as an artifact

## Upload to your existing S999 repository

**Important:** GitHub does NOT automatically unpack a ZIP uploaded into a repository. Extract the ZIP first, then upload its contents, maintaining the folders (including `.github/workflows`). The easiest method is on a computer: open your repository, select **Add file → Upload files**, drag all the extracted files and folders, and commit. Alternatively use GitHub Codespaces and its terminal to upload/unzip.

The repository may already contain a README.md. You can let this project's README replace it, or keep the existing README.

## Build without Android Studio

1. In GitHub open **Actions → Build S999 APK**.
2. Select **Run workflow** (or push a change to trigger a build).
3. Open the successful build run and download **S999-MKamuy-V1-debug-apk** under **Artifacts**.
4. Unzip that artifact to obtain `app-debug.apk`.
5. Transfer/install the APK on the S999 Android device, permitting installation from that source if prompted.
6. Open MKamuy S999. If you want it as the HOME interface, select it in Android Settings → Apps → Default apps → Home app (if your firmware allows this).

If the app causes difficulties, restore the device's original home app through Settings. **Do not delete your original launcher.**

## Compatibility
- Android 8.0 (API 26) or newer, subject to S999 vendor firmware restrictions
- Target API 35
- Requires JDK 17, Android SDK 35, Gradle 8.13, Android Gradle Plugin 8.13.2
- Builds a sideloadable *debug* APK, not a Play Store release

**Status:** Source package prepared; GitHub Actions build and S999 hardware compatibility have not yet been verified.
