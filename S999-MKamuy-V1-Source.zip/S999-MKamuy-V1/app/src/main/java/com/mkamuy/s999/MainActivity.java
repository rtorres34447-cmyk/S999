package com.mkamuy.s999;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Lightweight local-only HOME screen with Japanese-tech black/white design. */
public class MainActivity extends Activity {
    private static final int BLACK = Color.rgb(5, 5, 5);
    private static final int WHITE = Color.rgb(235, 235, 235);
    private static final int DIM = Color.rgb(136, 136, 136);
    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView timeText, dateText;
    private LinearLayout appRows;
    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            Date now = new Date();
            if (timeText != null) timeText.setText(new SimpleDateFormat("HH:mm", Locale.getDefault()).format(now));
            if (dateText != null) dateText.setText(new SimpleDateFormat("EEE  dd MMM yyyy", Locale.getDefault()).format(now).toUpperCase(Locale.getDefault()));
            handler.postDelayed(this, 15000);
        }
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BLACK);
        getWindow().setNavigationBarColor(BLACK);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        render();
    }

    private int dp(float n) { return (int) (n * getResources().getDisplayMetrics().density + .5f); }

    private TextView text(String value, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(color);
        t.setTextSize(size);
        t.setFontFeatureSettings("tnum");
        if (bold) t.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        t.setIncludeFontPadding(false);
        return t;
    }

    private GradientDrawable outline() {
        GradientDrawable b = new GradientDrawable();
        b.setColor(BLACK);
        b.setStroke(dp(1), Color.rgb(115, 115, 115));
        b.setCornerRadius(dp(2));
        return b;
    }

    private void render() {
        ScrollView scroller = new ScrollView(this);
        scroller.setBackgroundColor(BLACK);
        scroller.setFillViewport(true);
        scroller.setVerticalScrollBarEnabled(false);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(15), dp(10), dp(15), dp(16));
        scroller.addView(root);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView mark = text("武  MKAMUY", 16, WHITE, true);
        header.addView(mark, new LinearLayout.LayoutParams(0, dp(28), 1));
        TextView version = text("S999 / 01", 10, DIM, true);
        version.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        header.addView(version);
        root.addView(header);
        addRule(root, 0);

        TextView caption = text("PERSONAL INTERFACE   •   001", 9, DIM, true);
        caption.setLetterSpacing(.17f);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.topMargin = dp(12);
        root.addView(caption, cp);

        timeText = text("--:--", 56, WHITE, true);
        timeText.setGravity(Gravity.CENTER);
        timeText.setLetterSpacing(-.03f);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, dp(69));
        tp.topMargin = dp(4);
        root.addView(timeText, tp);

        dateText = text("", 11, DIM, true);
        dateText.setGravity(Gravity.CENTER);
        dateText.setLetterSpacing(.09f);
        root.addView(dateText);
        addRule(root, 12);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(11), dp(10), dp(11), dp(6));
        panel.setBackground(outline());
        TextView system = text("// SYSTEM ONLINE", 11, WHITE, true);
        system.setLetterSpacing(.14f);
        panel.addView(system);
        TextView hint = text("SWIPE TO EXPLORE   /   TAP TO LAUNCH", 9, DIM, false);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.topMargin = dp(7);
        panel.addView(hint, hp);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, -2);
        pp.bottomMargin = dp(14);
        root.addView(panel, pp);

        LinearLayout appsHeader = new LinearLayout(this);
        appsHeader.setGravity(Gravity.CENTER_VERTICAL);
        TextView appsLabel = text("01  /  APPLICATIONS", 12, WHITE, true);
        appsLabel.setLetterSpacing(.13f);
        appsHeader.addView(appsLabel, new LinearLayout.LayoutParams(0, dp(30), 1));
        TextView refresh = text("↻  REFRESH", 10, DIM, true);
        refresh.setGravity(Gravity.CENTER_VERTICAL);
        refresh.setOnClickListener(v -> populateApps());
        appsHeader.addView(refresh);
        root.addView(appsHeader);
        addRule(root, 0);

        appRows = new LinearLayout(this);
        appRows.setOrientation(LinearLayout.VERTICAL);
        root.addView(appRows);
        TextView footer = text("MKAMUY  /  MONOCHROME OS  /  V1", 9, DIM, true);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, dp(40));
        root.addView(footer, fp);
        setContentView(scroller);
        populateApps();
    }

    private void addRule(LinearLayout parent, int top) {
        View line = new View(this);
        line.setBackgroundColor(Color.rgb(112, 112, 112));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(1));
        lp.topMargin = dp(top);
        lp.bottomMargin = dp(6);
        parent.addView(line, lp);
    }

    private void populateApps() {
        appRows.removeAllViews();
        Intent query = new Intent(Intent.ACTION_MAIN);
        query.addCategory(Intent.CATEGORY_LAUNCHER);
        PackageManager pm = getPackageManager();
        List<ResolveInfo> apps = new ArrayList<>(pm.queryIntentActivities(query, 0));
        Collections.sort(apps, Comparator.comparing(a -> a.loadLabel(pm).toString().toLowerCase(Locale.ROOT)));
        int index = 1;
        for (ResolveInfo item : apps) {
            if (getPackageName().equals(item.activityInfo.packageName)) continue;
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setMinimumHeight(dp(44));
            TextView num = text(String.format(Locale.US, "%02d", index++), 10, DIM, true);
            row.addView(num, new LinearLayout.LayoutParams(dp(37), -2));
            TextView label = text(item.loadLabel(pm).toString(), 13, WHITE, true);
            label.setSingleLine(true);
            label.setEllipsize(android.text.TextUtils.TruncateAt.END);
            row.addView(label, new LinearLayout.LayoutParams(0, -2, 1));
            TextView arrow = text("›", 20, DIM, false);
            row.addView(arrow);
            row.setOnClickListener(v -> {
                try {
                    Intent launch = new Intent(Intent.ACTION_MAIN);
                    launch.addCategory(Intent.CATEGORY_LAUNCHER);
                    launch.setClassName(item.activityInfo.packageName, item.activityInfo.name);
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(launch);
                } catch (Exception ex) {
                    Toast.makeText(this, "Unable to launch app", Toast.LENGTH_SHORT).show();
                }
            });
            appRows.addView(row);
            addRule(appRows, 0);
        }
        if (index == 1) appRows.addView(text("No launchable apps found", 11, DIM, false));
    }

    @Override protected void onResume() {
        super.onResume();
        handler.removeCallbacks(ticker);
        ticker.run();
        if (appRows != null) populateApps();
    }
    @Override protected void onPause() {
        handler.removeCallbacks(ticker);
        super.onPause();
    }
}
